package com.cg.dao;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

public interface IQueryDAO {
	
	void plp();
	public abstract Inventory getBusinessByProducts(String inventoryName);
	public abstract Inventory getBusinessByMerchant(String merchantName);
	public abstract Inventory getBusinessByProductCatagory(String inventoryType);
	public abstract Merchant getBusinessByProductsAndMerchant(String inventoryName,Merchant merchant);
	
	
}
