package com.cg.dao;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnItem;
import com.cg.entities.SoldItem;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);
	     SoldItem soldItem = new SoldItem(1,"good", new Date());
	     soldItem.setCustomer(customer);
	     soldItem.setInventory(inventory);
	     ReturnItem returnItem = new ReturnItem(1, new Date());
	     returnItem.setSoldItem(soldItem);
	     
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.persist(soldItem);
	     entityManager.persist(returnItem);
	     entityManager.flush();
		
	}



	@Override
	public Inventory getBusinessByProducts(String inventoryName) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Inventory getBusinessByMerchant(String merchantName) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Inventory getBusinessByProductCatagory(String inventoryType) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Merchant getBusinessByProductsAndMerchant(String inventoryName, Merchant merchant) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
