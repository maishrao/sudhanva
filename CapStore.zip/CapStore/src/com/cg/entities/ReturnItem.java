package com.cg.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class ReturnItem implements Serializable {
	
	
	@Id
	private Integer returnItemId;
	
	@OneToOne
	@JoinColumn(name="solditem_fk")
	private SoldItem soldItem;
	
	private Date returnDate;

	public ReturnItem(Integer returnItemId, SoldItem soldItem, Date returnDate) {
		super();
		this.returnItemId = returnItemId;
		this.soldItem = soldItem;
		this.returnDate = returnDate;
	}

	public ReturnItem() {
		super();
	}

	public Integer getReturnItemId() {
		return returnItemId;
	}

	public void setReturnItemId(Integer returnItemId) {
		this.returnItemId = returnItemId;
	}

	public SoldItem getSoldItem() {
		return soldItem;
	}

	public void setSoldItem(SoldItem soldItem) {
		this.soldItem = soldItem;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public ReturnItem(Integer returnItemId, Date returnDate) {
		super();
		this.returnItemId = returnItemId;
		this.returnDate = returnDate;
	}
	
	
	
	

}
