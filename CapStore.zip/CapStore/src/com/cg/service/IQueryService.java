package com.cg.service;

import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

public interface IQueryService {

	
void plp();

public abstract Inventory getBusinessByProducts(String inventoryName);
public abstract Inventory getBusinessByMerchant(String merchantName);
public abstract Inventory getBusinessByProductCatagory(String inventoryType);
public abstract Inventory getBusinessByProductsAndMerchant(String inventoryName,Merchant merchant);


}
